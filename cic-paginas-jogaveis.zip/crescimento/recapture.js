(function(){
'use strict';
const M=window.CicRecaptureModel, $=id=>document.getElementById(id);
const nearLabel='Só perto do barco', mixLabel='Baía toda', fmt=n=>n.toLocaleString('pt-BR');
const palette={10:'#235e99',20:'#6e438a',30:'#1b785b'};
let world,marked,history,phase,revealed;
const fish=(id,isMarked)=>{
 const color=['#447d94','#567c66','#49788d','#866951'][id%4];
 return `<svg viewBox="0 0 44 28" aria-hidden="true"><path d="M13 14 3 6l2 8-2 8z" fill="${color}"/><path d="M9 14Q23-2 40 12l2 2-2 2Q24 30 9 14Z" fill="${color}" stroke="#27475b" stroke-width="1.2"/><path d="M12 14q12 8 27 1Q25 26 14 18" fill="#e1e7de" opacity=".63"/><path d="m21 8 4-5 6 4M24 14l5 5-7-1" fill="${color}" stroke="#27475b" stroke-width=".6"/><circle cx="36.5" cy="12" r="1.8" fill="#eef7f7"/><circle cx="37" cy="12" r=".9" fill="#173b4c"/>${isMarked?'<circle cx="18" cy="14" r="4.2" stroke="#593e02" stroke-width="3.7" fill="none"/><circle cx="18" cy="14" r="4.2" stroke="#ffce42" stroke-width="2.4" fill="none"/>':''}</svg>`;
};
function tray(sample,title){
 $('fTrayTitle').textContent=title;
 const tagged=sample.filter(f=>marked.has(f.id)).length;
 $('fTray').setAttribute('aria-label',sample.length?sample.length+' peixes na amostra, '+tagged+' marcados':'Nenhum peixe na amostra');
 $('fTray').innerHTML=sample.length?sample.map(f=>fish(f.id,marked.has(f.id))).join(''):'<p>Nenhum peixe na amostra.</p>';
}
function graph(){
 const offset=Math.max(0,history.length-12), rows=history.slice(offset);
 const vmax=Math.max(40,revealed?world.total:0,...rows.map(r=>r.estimate??0));
 const step=10**Math.floor(Math.log10(vmax/4));
 const gridStep=Math.ceil(vmax/(4*step))*step, max=4*gridStep;
 const x=i=>63+(i+.5)*387/rows.length, y=v=>185-150*v/max;
 const legend=Object.entries(palette).map(([n,c])=>`<span><i style="--dot:${c}"></i>${n} na amostra</span>`).join('');
 return `<div class="f-chartwrap"><svg viewBox="0 0 475 224" role="img" aria-label="Estimativas por tentativa. Os valores exatos estão na tabela.">
 <text x="63" y="17" font-size="13" fill="#29495f">Peixes estimados</text>
 ${[0,1,2,3,4].map(n=>`<line x1="63" x2="450" y1="${y(n*gridStep)}" y2="${y(n*gridStep)}" stroke="#dce7ee"/><text x="57" y="${y(n*gridStep)+4}" text-anchor="end" fill="#38556b" font-size="13">${fmt(n*gridStep)}</text>`).join('')}
 ${revealed?`<line x1="63" x2="450" y1="${y(world.total)}" y2="${y(world.total)}" stroke="#274757" stroke-width="2" stroke-dasharray="4 4"/>`:''}
 ${rows.map((r,i)=>`<text x="${x(i)}" y="202" text-anchor="middle" fill="#38556b" font-size="12">${offset+i+1}</text>`+(r.estimate===null?`<text x="${x(i)}" y="176" text-anchor="middle" fill="#516a79" font-size="16">×</text>`:r.mixed?`<circle cx="${x(i)}" cy="${y(r.estimate)}" r="6" fill="${palette[r.n]}" stroke="white" stroke-width="1.5"/>`:`<rect x="${x(i)-5}" y="${y(r.estimate)-5}" width="10" height="10" rx="1" fill="${palette[r.n]}"/>`)).join('')}
 <text x="257" y="221" text-anchor="middle" fill="#29495f" font-size="13">Tentativa</text></svg></div>
 <div class="f-legend">${legend}<span>● Baía toda</span><span>■ Só perto do barco</span><span>× Sem estimativa</span>${revealed?'<span>┄ Total real</span>':''}</div>`+(offset?'<p class="subtle">O gráfico mostra as últimas 12 tentativas. A tabela mantém todas.</p>':'');
}
function results(){
 const last=history.at(-1);
 $('fReveal').disabled=!last||revealed;
 $('fTruth').hidden=!revealed;
 $('fChart').hidden=!last;
 $('fHistory').hidden=!last;
 if(!last){
   $('fEstimate').textContent='Sua primeira estimativa vai aparecer aqui.';
   $('fTruth').textContent='';$('fChart').innerHTML='';$('fHistory').innerHTML='';
   return;
 }
 const share=(last.matches/last.n).toLocaleString('pt-BR',{style:'percent',maximumFractionDigits:1});
 $('fEstimate').textContent=last.estimate===null?'Nenhum marcado voltou nesta tentativa. Não dá para estimar dividindo por zero. Tente de novo ou aumente a amostra.':`${last.matches} de ${last.n} recapturados tinham marca (${share}). ${marked.size} × ${last.n} ÷ ${last.matches} ≈ ${fmt(last.estimate)} peixes na baía.`;
 if(revealed){
   const e=last.estimate===null?null:last.estimate-world.total;
   $('fTruth').textContent='Total real da baía simulada: '+fmt(world.total)+' peixes.'+(e===null?'':e===0?' A última estimativa acertou.':` A última estimativa ficou ${fmt(Math.abs(e))} ${Math.abs(e)===1?'peixe':'peixes'} ${e<0?'abaixo':'acima'} do total.`);
 }
 $('fChart').innerHTML=graph();
 $('fHistory').innerHTML='<table><thead><tr><th scope="col">Tentativa</th><th scope="col">Local</th><th scope="col">Amostra</th><th scope="col">Marcados</th><th scope="col">Estimativa</th></tr></thead><tbody>'+history.map((r,i)=>'<tr'+(r===last?' class="selected"':'')+'><td>'+(i+1)+'</td><td>'+(r.mixed?mixLabel:nearLabel)+'</td><td>'+r.n+'</td><td>'+r.matches+'</td><td>'+(r.estimate===null?'Sem estimativa':fmt(r.estimate))+'</td></tr>').join('')+'</tbody></table>';
}
function stage(message){
 $('fStage').textContent=message;
 $('fMarkN').disabled=phase!=='start';
 $('fMark').hidden=phase!=='start';
 $('fRelease').hidden=phase!=='marked';
 $('fRecaptureOptions').hidden=phase!=='released';
}
function reset(){
 world=M.create();marked=new Set();history=[];phase='start';revealed=false;
 $('fMarkN').value='20';$('fCatchN').value='20';$('fMix').value='mixed';
 stage('Comece capturando os peixes perto do barco.');tray([],'Peixes na amostra');results();
}
$('fMark').onclick=()=>{
 if(phase!=='start')return;
 const sample=M.draw(world.fish.filter(f=>f.zone==='perto'),Number($('fMarkN').value));
 marked=new Set(sample.map(f=>f.id));phase='marked';
 tray(sample,'Primeira captura');stage(marked.size+' peixes receberam uma marca. Solte todos antes de recapturar.');
};
$('fRelease').onclick=()=>{
 if(phase!=='marked')return;
 phase='released';tray([],'Peixes na amostra');
 stage(marked.size+' peixes marcados voltaram para a água. Escolha como recapturar.');
};
$('fCatch').onclick=()=>{
 if(phase!=='released')return;
 const n=Number($('fCatchN').value),mixed=$('fMix').value==='mixed';
 const {sample,matches,estimate}=M.recapture(world,marked,n,mixed);
 history.push({n,mixed,matches,estimate});
 tray(sample,'Recaptura · tentativa '+history.length);
 stage(matches+' de '+n+' voltaram com marca. Confira a estimativa abaixo ou repita.');
 results();
};
$('fReveal').onclick=()=>{if(history.length){revealed=true;results();}};
$('fReset').onclick=reset;
reset();
})();
