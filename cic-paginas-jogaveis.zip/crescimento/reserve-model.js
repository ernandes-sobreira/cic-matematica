(function (root, factory) {
  const model = factory();
  if (typeof module === 'object' && module.exports) module.exports = model;
  if (root) root.CicReserveModel = model;
})(typeof window === 'object' ? window : null, function () {
  'use strict';
  const W = 12, H = 8, LIMIT = 36;
  const valid = i => Number.isInteger(i) && i >= 0 && i < W * H;

  function rectangle(w, h) {
    if (!Number.isInteger(w) || !Number.isInteger(h) || w < 1 || h < 1 ||
        w > W || h > H || w * h > LIMIT) return [];
    const x0 = Math.floor((W - w) / 2), y0 = Math.floor((H - h) / 2);
    return Array.from({ length: w * h }, (_, i) =>
      (y0 + Math.floor(i / w)) * W + x0 + i % w);
  }

  function exposed(index, cells) {
    const x = index % W, y = Math.floor(index / W);
    return Number(x === 0 || !cells.has(index - 1)) +
      Number(x === W - 1 || !cells.has(index + 1)) +
      Number(y === 0 || !cells.has(index - W)) +
      Number(y === H - 1 || !cells.has(index + W));
  }

  function isInterior(index, cells) {
    const selected = cells instanceof Set ? cells : new Set(cells);
    return valid(index) && selected.has(index) && exposed(index, selected) === 0;
  }

  function measure(cells) {
    const selected = new Set(Array.from(cells).filter(valid));
    let perimeter = 0, border = 0;
    for (const i of selected) {
      const edges = exposed(i, selected);
      perimeter += edges;
      if (edges) border++;
    }
    const area = selected.size;
    return { area, perimeter, border, interior: area - border };
  }

  return { W, H, LIMIT, rectangle, measure, isInterior };
});
