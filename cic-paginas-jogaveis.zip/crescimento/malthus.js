(function(root) {
  'use strict';
  const limits = [0, 5], clamp = n => Math.max(limits[0], Math.min(limits[1], n));
  const model = i => ({ people: 2 ** i, food: 7 + 3 * i });
  const rows = Array.from({ length: limits[1] + 1 }, (_, i) => model(i));
  const $ = s => document.getElementById(s);
  let round = 0, pointer = null;
  const x = i => 41 + i * (360 / limits[1]);
  const y = v => 177 - v * 3.85;
  const line = key => rows.map((d,i) => x(i)+','+y(d[key])).join(' ');
  const graphic = (n, f) => `<svg viewBox="0 0 420 224" role="img" aria-label="Comunidade ilustrada com ${n} ${n===1?'pessoa':'pessoas'} e ${f} caixas de alimento">
  <defs>
  <linearGradient id="mSky" x2="0" y2="1"><stop stop-color="#91d4f3"/><stop offset="1" stop-color="#e9f8ff"/></linearGradient>
  <linearGradient id="mGround" x2="0" y2="1"><stop stop-color="#c2da91"/><stop offset="1" stop-color="#dceab1"/></linearGradient>
  <symbol id="mPersonIcon" viewBox="0 0 22 34"><ellipse cx="11" cy="31" rx="9" ry="2.3" fill="#506042" opacity=".25"/><path d="M8 19v10m6-10v10" stroke="#2c4559" stroke-width="3.8" stroke-linecap="round"/><path d="M5.5 13.5 3 20m13.5-6.5L19 20" stroke="#aa6e4a" stroke-width="2.3" stroke-linecap="round"/><path d="M6 13q5-5 10 0l.5 8h-11z" fill="currentColor"/><circle cx="11" cy="7" r="4.6" fill="#bd835b"/><path d="M6.5 7Q5 1 11 1q5 0 4.7 5L13 4l-2.5 1L8 4z" fill="#463129"/></symbol>
  <symbol id="mBoxIcon" viewBox="0 0 24 20"><path d="m1 7 6-4h15l-4 4v12H1z" fill="#f4b25a" stroke="#944513" stroke-width="1"/><path d="m18 7 4-4v11l-4 5z" fill="#c7732d"/><path d="M2 11h15m-15 4h15m-7-8v11" stroke="#944513" opacity=".7"/><circle cx="7" cy="5" r="3" fill="#df603a"/><circle cx="12" cy="4.6" r="3" fill="#88a44d"/><circle cx="17" cy="5" r="2.8" fill="#e9a126"/></symbol>
  </defs>
  <rect width="420" height="224" fill="url(#mSky)"/><circle cx="365" cy="32" r="16" fill="#fff2b6"/><path d="M0 81Q50 18 118 79Q182 26 256 79Q336 39 420 82V123H0z" fill="#b8ce9e"/><path d="M0 97Q89 77 148 96T285 91T420 100V224H0z" fill="url(#mGround)"/><path d="M215 105q-6 37 0 119h-23q10-87 12-119z" fill="#ead5a1" opacity=".75"/>
  <path d="M262 74h107l16 24H248z" fill="#a86442"/><path d="M254 98h124v98H254z" fill="#f3deb4" stroke="#946547" stroke-width="2"/><rect x="263" y="105" width="107" height="76" rx="5" fill="#d4a578"/>
  ${Array.from({length:n},(_,j)=>`<use href="#mPersonIcon" x="${13+(j%9)*19+(Math.floor(j/9)%2)*3}" y="${82+Math.floor(j/9)*30}" width="18" height="29" color="${['#17658d','#914c94','#366e62','#b54a2f','#31539b'][j%5]}"/>`).join('')}
  ${Array.from({length:f},(_,j)=>`<use href="#mBoxIcon" x="${266+(j%5)*20}" y="${163-Math.floor(j/5)*14}" width="20" height="16"/>`).join('')}
  </svg>`;
  const chart = i => {
    const {people,food}=rows[i];
    return `<svg viewBox="0 0 420 224" role="img" aria-label="Rodada ${i}: ${people} porções necessárias, ${food} produzidas">
    <text x="41" y="14" fill="#29495f" font-size="14">Porções</text>
    ${[0,10,20,30,40].map(v=>`<line x1="41" x2="401" y1="${y(v)}" y2="${y(v)}" stroke="#dce7ee"/><text x="34" y="${y(v)+4}" text-anchor="end" fill="#38556b" font-size="13">${v}</text>`).join('')}
    ${rows.map((_,j)=>`<text x="${x(j)}" y="196" text-anchor="middle" font-size="13" fill="#38556b">${j}</text>`).join('')}
    <rect x="${x(i)-10}" y="23" width="20" height="154" rx="8" fill="#dbe7f0" opacity=".7"/>
    <polyline points="${line('people')}" fill="none" stroke="#17658d" stroke-width="3" stroke-linejoin="round"/>
    <polyline points="${line('food')}" fill="none" stroke="#a74912" stroke-width="3" stroke-dasharray="6 4" stroke-linejoin="round"/>
    <circle cx="${x(i)}" cy="${y(people)}" r="5" fill="#17658d" stroke="white" stroke-width="2"/>
    <circle cx="${x(i)}" cy="${y(food)}" r="5" fill="#a74912" stroke="white" stroke-width="2"/>
    <text x="221" y="217" text-anchor="middle" fill="#29495f" font-size="14">Rodada</text>
    </svg>`;
  };
  function render(){
    const {people,food}=rows[round], gap=food-people;
    $('mPeople').textContent=people; $('mFood').textContent=food;
    const perPerson=(food/people).toLocaleString('pt-BR',{maximumFractionDigits:2});
    $('mGap').textContent=perPerson;
    $('mRound').value=round; $('mRoundOut').textContent=round+' de '+limits[1];
    $('mRound').setAttribute('aria-valuetext','Rodada '+round+' de '+limits[1]);
    $('mBack').disabled=round===0; $('mNext').disabled=round===limits[1];
    $('mScene').innerHTML=graphic(people,food); $('mChart').innerHTML=chart(round);
    $('mStatus').textContent=`Rodada ${round}: ${people} ${people===1?'pessoa':'pessoas'} e ${food} porções produzidas (${perPerson} por pessoa). ${gap<0?'Faltam '+(-gap)+' porções.':gap>0?'Sobram '+gap+' porções.':'Estoque exato.'}`;
  }
  function select(n){if(Number.isFinite(n)){round=clamp(Math.round(n));render();}}
  if(typeof document!=='undefined'){
    $('mRound').addEventListener('input',e=>select(Number(e.target.value)));
    $('mBack').addEventListener('click',()=>select(round-1));
    $('mNext').addEventListener('click',()=>select(round+1));
    const plot=$('mChart');
    const scrub=e=>{const b=plot.getBoundingClientRect();if(b.width)select(((e.clientX-b.left)*420/b.width-41)/(360/limits[1]));};
    plot.addEventListener('pointerdown', e=>{if(!e.isPrimary||e.button!==0)return;pointer=e.pointerId;plot.setPointerCapture(e.pointerId);scrub(e);});
    plot.addEventListener('pointermove', e=>{if(e.pointerId===pointer)scrub(e);});
    ['pointerup','pointercancel','lostpointercapture'].forEach(name=>plot.addEventListener(name,e=>{if(e.pointerId===pointer)pointer=null;}));
  }
  root.CicMalthus={render};
  if(typeof module!=='undefined')module.exports={model,rows,graphic,chart};
})(globalThis);
