(function(){
'use strict';
const R=window.CicReserveModel, $=id=>document.getElementById(id);
const choices={A:new Set(R.rectangle(6,6)),B:new Set(R.rectangle(12,3))};
const cells={A:[],B:[]}, current={A:0,B:0};
function focusMap(key,i){
 cells[key][current[key]].tabIndex=-1;
 current[key]=i;cells[key][i].tabIndex=0;cells[key][i].focus();
}
for(const key of ['A','B']){
 const map=$('rMap'+key);
 for(let i=0;i<R.W*R.H;i++){
  const x=i%R.W,y=Math.floor(i/R.W);
  const b=document.createElement('button');b.type='button';b.className='r-cell';b.tabIndex=i===0?0:-1;
  b.addEventListener('click',()=>{
   const set=choices[key];
   focusMap(key,i);
   if(set.has(i))set.delete(i);
   else if(set.size<R.LIMIT)set.add(i);
   else{ $('rCompare').textContent='A Reserva '+key+' já tem 36 quadradinhos. Retire um para incluir outro.';return; }
   render();
  });
  b.addEventListener('keydown',e=>{
   const delta={ArrowLeft:x>0?-1:0,ArrowRight:x<R.W-1?1:0,ArrowUp:y>0?-R.W:0,ArrowDown:y<R.H-1?R.W:0};
   if(!(e.key in delta))return;
   e.preventDefault();focusMap(key,i+delta[e.key]);
  });
  cells[key].push(b);map.appendChild(b);
 }
}
document.querySelectorAll('[data-rfill]').forEach(b=>b.addEventListener('click',()=>{
 const [key,w,h]=b.dataset.rfill.split(',');
 choices[key]=new Set(+w&&+h?R.rectangle(+w,+h):[]);
 render();
}));
function render(){
 const measures={};
 for(const key of ['A','B']){
  const set=choices[key], m=measures[key]=R.measure(set);
  $('rBudget'+key).textContent=m.area+' / '+R.LIMIT+' quadradinhos';
  $('rRead'+key).textContent='Perímetro: '+m.perimeter+' lados';
  cells[key].forEach((b,i)=>{
   const selected=set.has(i),core=selected&&R.isInterior(i,set);
   b.classList.toggle('r-core',core);b.classList.toggle('r-edge',selected&&!core);
   b.setAttribute('aria-pressed',String(selected));
   b.setAttribute('aria-label','Linha '+(Math.floor(i/R.W)+1)+', coluna '+(i%R.W+1)+': '+(core?'mata interior':selected?'borda':'fora da reserva'));
  });
 }
 const {A,B}=measures, graph=$('rGraph');
 graph.setAttribute('aria-label',`Em células: A tem ${A.interior} de interior e ${A.border} de borda. B tem ${B.interior} de interior e ${B.border} de borda.`);
 graph.innerHTML=['A','B'].map(key=>{
   const m=measures[key], percent=v=>100*v/R.LIMIT+'%';
   return `<div class="r-chart-row" aria-hidden="true"><b>${key}</b><div class="r-track"><i class="r-bar-core" style="width:${percent(m.interior)}"></i><i class="r-bar-edge" style="width:${percent(m.border)}"></i></div><span>${m.interior} interior · ${m.border} borda</span></div>`;
 }).join('')+'<div class="r-chart-row r-chart-axis" aria-hidden="true"><span></span><div><span>0</span><span>18</span><span>36 células</span></div><span></span></div>';
 if(A.area!==B.area||A.area!==R.LIMIT){
   $('rCompare').textContent='Complete 36 células em cada mapa para comparar só o efeito da forma.';return;
 }
 const diff=A.interior-B.interior;
 const improvement=B.interior-10;
 $('rCompare').textContent=improvement>0
   ?`Você ganhou ${improvement} ${improvement===1?'célula':'células'} de mata interior na Reserva B, com a mesma área.`
   :diff===0?'Mesma área, mesmo interior. Tente outra forma para ampliar o interior em B.'
   :`Mesma área, mas a Reserva ${diff>0?'A':'B'} tem ${Math.abs(diff)} ${Math.abs(diff)===1?'célula a mais':'células a mais'} de mata interior.`;
}
render();
})();
