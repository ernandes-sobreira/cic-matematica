(function (root, factory) {
  const model = factory();
  if (typeof module === 'object' && module.exports) module.exports = model;
  if (root) root.CicRecaptureModel = model;
})(typeof window === 'object' ? window : null, function () {
  'use strict';

  function create(rng = Math.random) {
    const total = 65 + Math.floor(rng() * 71);
    const fish = Array.from({ length: total }, (_, idx) => ({
      id: idx + 1,
      zone: idx % 2 === 0 ? 'longe' : 'perto'
    }));
    return { total, fish };
  }

  function draw(fish, n, rng = Math.random) {
    const count = Math.max(0, Math.min(fish.length, Math.trunc(n) || 0));
    const pool = fish.slice();
    for (let i = 0; i < count; i++) {
      const j = i + Math.floor(rng() * (pool.length - i));
      [pool[i], pool[j]] = [pool[j], pool[i]];
    }
    return pool.slice(0, count);
  }

  function recapture(world, markedIds, n, mixed = true, rng = Math.random) {
    const marked = new Set(markedIds);
    const pool = mixed ? world.fish : world.fish.filter(f => f.zone === 'perto');
    const sample = draw(pool, n, rng);
    const matches = sample.filter(f => marked.has(f.id)).length;
    const estimate = matches === 0 ? null : Math.round(marked.size * sample.length / matches);
    return { sample, matches, estimate };
  }

  return { create, draw, recapture };
});
