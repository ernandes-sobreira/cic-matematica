(function(root){
 function linear(n,a,t){return n+a*t}
 function exponential(n,p,t){return n*Math.pow(1+p,t)}
 function logistic(n,p,k,t){if(n===0)return 0;return k/(1+(k/n-1)*Math.exp(-Math.log1p(p)*t))}
 function series({model,n,p,a,k,removal=0,steps=30}){const out=[n];for(let t=1;t<=steps;t++){const prev=out[t-1],grown=model==='linear'?prev+a:model==='exponential'?exponential(prev,p,1):logistic(prev,p,k,1);out.push(Math.max(0,grown*(1-removal)))}return out}
 function gridStats(cells){const n=cells.length,occupied=cells.filter(v=>v>0).length,total=cells.reduce((a,b)=>a+b,0);return {n,occupied,frequency:n?occupied/n*100:0,coverage:n?total/n:0,total}}
 function plantStats(plants,radius=18){const counts=Array(25).fill(0);plants.forEach(p=>counts[Math.min(4,Math.floor(p.y/100))*5+Math.min(4,Math.floor(p.x/100))]++);const mask=new Uint8Array(40000);for(const p of plants){const x0=Math.max(0,Math.floor((p.x-radius)/2.5)),x1=Math.min(199,Math.ceil((p.x+radius)/2.5)),y0=Math.max(0,Math.floor((p.y-radius)/2.5)),y1=Math.min(199,Math.ceil((p.y+radius)/2.5));for(let iy=y0;iy<=y1;iy++)for(let ix=x0;ix<=x1;ix++){const x=ix*2.5+1.25,y=iy*2.5+1.25;if((p.x-x)**2+(p.y-y)**2<=radius**2)mask[iy*200+ix]=1}}let covered=0,water=0;for(let iy=0;iy<200;iy++)for(let ix=0;ix<200;ix++){const x=ix*2.5+1.25,y=iy*2.5+1.25;if(((x-250)/235)**2+((y-250)/210)**2>1)continue;water++;covered+=mask[iy*200+ix]}const occupied=counts.filter(n=>n>0).length;return {counts,occupied,frequency:occupied/25*100,coverage:water?covered/water*100:0}}
 root.Growth={plantStats,linear,exponential,logistic,series,gridStats};
})(typeof window==='undefined'?globalThis:window);
