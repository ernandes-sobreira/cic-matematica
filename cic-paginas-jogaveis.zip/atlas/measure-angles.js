/* Angle labels are a display layer; drawing coordinates and saved records are unchanged. */
(function(){
 const svg=$('drawing'),bar=document.createElement('div');bar.className='measure-angle-controls';
 bar.innerHTML='<label><input id="mapShowAngles" type="checkbox" checked>Ângulos no desenho</label><select id="mapAngleVertex" aria-label="Ângulos para mostrar"><option value="all">Todos os vértices</option></select>';
 $('map').before(bar);let layer=map&&L.layerGroup().addTo(map);
 function clear(){if(layer)layer.clearLayers();svg.querySelector('#measureAngleOverlay')?.remove()}
 function info(){
  const st=stats();if(tool==='distance'||st.circle||!st.path||st.path.length<3)return null;
  const path=st.path,photo=context==='photo';if(!photo&&!map)return null;const ps=photo?path.map(p=>[...p]):path.map(p=>{const z=map.getZoom(),q=map.project(p,z),c=map.project(map.getCenter(),z),size=map.getSize();return[q.x-c.x+size.x/2,q.y-c.y+size.y/2]});
  const a=ShapeMath.analyze(ps),signed=ps.reduce((s,p,i)=>s+p[0]*ps[(i+1)%ps.length][1]-ps[(i+1)%ps.length][0]*p[1],0);
  return {path,ps,a,photo,side:signed>0?-1:1};
 }
 function draw(){
  clear();const d=info();bar.hidden=!d;$('mapShowAngles').closest('label').hidden=!d;if(!d||!$('mapShowAngles').checked){$('mapAngleVertex').hidden=true;return}
  const select=$('mapAngleVertex'),old=select.value;select.hidden=false;if(select.options.length!==d.ps.length+1){select.replaceChildren();const all=document.createElement('option');all.value='all';all.textContent='Todos os vértices';select.append(all);d.ps.forEach((p,i)=>{const o=document.createElement('option');o.value=String(i);o.textContent='Vértice '+String.fromCharCode(65+i%26);select.append(o)});select.value=[...select.options].some(o=>o.value===old)?old:'all'}
  const selected=select.value,photoScale=d.photo?Math.abs(svg.getScreenCTM()?.a||1):1;
  const screen=d.photo?d.ps.map(p=>p.map(v=>v*photoScale)):d.ps;
  let markup='';
  for(let i=0;i<screen.length;i++){
   if(selected!=='all'&&selected!==String(i))continue;
   const n=screen.length,a=screen[(i+n-1)%n],b=screen[i],c=screen[(i+1)%n],u=[a[0]-b[0],a[1]-b[1]],v=[c[0]-b[0],c[1]-b[1]],lu=Math.hypot(...u),lv=Math.hypot(...v);
   if(lu<1e-6||lv<1e-6)continue;
   const minor=Math.atan2(Math.abs(u[0]*v[1]-u[1]*v[0]),u[0]*v[0]+u[1]*v[1])*180/Math.PI;
   let value=d.a.angles.length===n?d.a.angles[i]:minor;if(!d.photo&&n===3){const ab=dist(d.path[(i+n-1)%n],d.path[i],false),bc=dist(d.path[i],d.path[(i+1)%n],false),ac=dist(d.path[(i+n-1)%n],d.path[(i+1)%n],false);value=Math.acos(Math.max(-1,Math.min(1,(ab*ab+bc*bc-ac*ac)/(2*ab*bc))))*180/Math.PI}const side=d.a.angles.length===n?d.side:(u[0]*v[1]-u[1]*v[0]<0?-1:1),start=Math.atan2(u[1],u[0]),delta=side*value*Math.PI/180,r=Math.min(23,lu*.27,lv*.27),mid=start+delta/2,labelR=Math.max(r+15,32),label=[b[0]+labelR*Math.cos(mid),b[1]+labelR*Math.sin(mid)],text=fmt(value,1)+'°';
   const segments=Math.max(8,Math.ceil(value/8));const arc=Array.from({length:segments+1},(_,j)=>{const t=start+delta*j/segments;return[b[0]+r*Math.cos(t),b[1]+r*Math.sin(t)]});
   if(d.photo){const points=arc.map(p=>p.map(v=>v/photoScale).join(',')).join(' ');markup+='<polyline points="'+points+'" fill="none" stroke="#b75b0b" stroke-width="'+2/photoScale+'"/><text x="'+label[0]/photoScale+'" y="'+label[1]/photoScale+'" text-anchor="middle" dominant-baseline="middle" font-family="system-ui" font-weight="600" font-size="'+13/photoScale+'" fill="#8e4208" stroke="white" stroke-width="'+4/photoScale+'" paint-order="stroke">'+text+'</text>'}
   else{L.polyline(arc.map(p=>map.containerPointToLatLng(p)),{color:'#a64e0c',weight:2,interactive:false,bubblingMouseEvents:false}).addTo(layer);L.marker(map.containerPointToLatLng(label),{interactive:false,keyboard:false,icon:L.divIcon({className:'map-angle-label',html:'<span>'+text+'</span>',iconSize:[62,24],iconAnchor:[31,12]}),zIndexOffset:800}).addTo(layer)}
  }
  if(d.photo&&markup){const g=document.createElementNS('http://www.w3.org/2000/svg','g');g.id='measureAngleOverlay';g.setAttribute('pointer-events','none');g.innerHTML=markup;svg.append(g)}
 }
 $('mapShowAngles').onchange=draw;$('mapAngleVertex').onchange=draw;
 const original=render;render=function(...args){original(...args);draw()};
 if(map)map.on('zoomend moveend resize',draw);
 window.MeasureAngles={draw};draw();
})();
