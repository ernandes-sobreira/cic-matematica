(function(){
const page=document.body.dataset.mathPage;if(!page)return;
const $=id=>document.getElementById(id),one=(s,r=document)=>r.querySelector(s);
document.body.classList.add('math-minimal');
const icons={map:'<path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3Z M9 3v15 M15 6v15"/>',photo:'<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8" cy="8" r="1.5"/><path d="m3 17 6-6 5 5 3-3 4 4"/>',water:'<path d="M2 8c3-5 5 5 8 0s5 5 8 0 4 0 4 0M2 15c3-5 5 5 8 0s5 5 8 0 4 0 4 0"/>',land:'<path d="m3 18 5-12 6 5 4-5 3 12Z M8 6l6 5"/>',stats:'<path d="M4 3v17h17 M8 16v-5 M13 16V6 M18 16V9"/>',model:'<path d="m4 16 5-7 6 5 5-10 M4 20h17"/><circle cx="9" cy="9" r="2"/><circle cx="15" cy="14" r="2"/>',folder:'<path d="M3 7V5h7l2 2h9v13H3Z"/>',book:'<path d="M12 5v15 M3 4c4-1 6 0 9 2 3-2 5-3 9-2v14c-4-1-6 0-9 2-3-2-5-3-9-2Z"/>',layers:'<path d="m3 8 9-5 9 5-9 5Z M3 13l9 5 9-5 M3 18l9 5 9-5"/>',menu:'<path d="M4 6h16 M4 12h16 M4 18h16"/>'};
function icon(key){return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+icons[key]+'</svg>'}
const header=one('body>header');header.classList.add('minimal-header');
const menu=document.createElement('button');menu.className='rail-toggle';menu.type='button';menu.innerHTML=icon('menu')+'<span>Menu</span>';menu.setAttribute('aria-label','Abrir menu da Matemática');header.prepend(menu);
const controls=document.createElement('div');controls.className='minimal-header-actions';header.append(controls);
function dialog(title){const d=document.createElement('dialog');d.className='minimal-dialog';d.setAttribute('aria-label',title);const h=document.createElement('div');h.className='minimal-dialog-heading';const t=document.createElement('h2');t.textContent=title;const close=document.createElement('button');close.textContent='Fechar';close.type='button';close.onclick=()=>d.close();h.append(t,close);const body=document.createElement('div');body.className='minimal-dialog-body';d.append(h,body);document.body.append(d);d.addEventListener('click',e=>{if(e.target===d){const b=d.getBoundingClientRect();if(e.clientX<b.left||e.clientX>b.right||e.clientY<b.top||e.clientY>b.bottom)d.close()}});return {el:d,body,open:()=>{closeRail();d.showModal()}}}
function topButton(text,target,aria){const b=document.createElement('button');b.textContent=text;b.type='button';if(aria)b.setAttribute('aria-label',aria);b.onclick=target.open;controls.append(b);return b}
const help=dialog('Orientações e créditos');const turma=dialog('Turma');
topButton('?',help,'Orientações e créditos');
const rail=document.createElement('nav');rail.className='math-rail';rail.setAttribute('aria-label','Menu da Matemática');rail.innerHTML='<div class="rail-title">Matemática</div><div class="rail-primary"></div><div class="rail-secondary"></div><div class="rail-bottom"></div>';header.after(rail);
const backdrop=document.createElement('button');backdrop.className='rail-backdrop';backdrop.setAttribute('aria-label','Fechar menu');document.body.append(backdrop);
function closeRail(){document.body.classList.remove('rail-open');menu.setAttribute('aria-expanded','false');rail.inert=window.matchMedia('(max-width:850px)').matches;}menu.onclick=()=>{const open=document.body.classList.toggle('rail-open');menu.setAttribute('aria-expanded',String(open));rail.inert=!open&&window.matchMedia('(max-width:850px)').matches;};backdrop.onclick=closeRail;document.addEventListener('keydown',e=>{if(e.key==='Escape')closeRail()});
const compactRail=window.matchMedia('(max-width:850px)');compactRail.addEventListener('change',()=>{rail.inert=compactRail.matches&&!document.body.classList.contains('rail-open')});rail.inert=compactRail.matches;
function railItem(el,key,label,section='primary'){el.classList.add('rail-item');el.replaceChildren();el.insertAdjacentHTML('afterbegin',icon(key));const txt=document.createElement('span');txt.textContent=label;el.append(txt);one('.rail-'+section,rail).append(el);el.addEventListener('click',closeRail);return el}
function link(key,label,href,section){const el=document.createElement('a');el.href=href;return railItem(el,key,label,section)}
function action(key,label,fn,section){const b=document.createElement('button');b.type='button';b.onclick=fn;return railItem(b,key,label,section)}

['contextTitle','lessonTitle','sTitle'].forEach(id=>{if($(id)){$(id).setAttribute('role','heading');$(id).setAttribute('aria-level','1')}});document.querySelectorAll('#agro>.heading h2,.river-history>.heading h2').forEach(h=>h.setAttribute('aria-level','1'));
function fold(node,title,open=false){if(!node)return;const d=document.createElement('details');d.className='minimal-fold';d.open=open;const s=document.createElement('summary');s.textContent=title;node.before(d);d.append(s,node);return d}
function moveHelp(node){if(node)help.body.append(node)}
document.querySelectorAll('main a').forEach(a=>{if(/[↗→↓]/.test(a.textContent))a.textContent=a.textContent.replace(/[↗→↓]/g,'').trim()});
function invalidate(){if(page==='geometry'&&typeof map!=='undefined'&&map)requestAnimationFrame(()=>map.invalidateSize());if(page==='advanced'&&typeof agMap!=='undefined'&&agMap)requestAnimationFrame(()=>agMap.invalidateSize())}
if(page==='geometry'){
 const labels={city:['map','Mapa'],photo:['photo','Catedral'],water:['water','Rios e baías'],land:['land','Áreas rurais']};
 const ctxButtons=[...document.querySelectorAll('[data-context]')];
 ctxButtons.forEach(b=>{const [i,label]=labels[b.dataset.context];railItem(b,i,label);b.addEventListener('click',()=>{if(b.dataset.context==='photo'&&photoView==='custom')loadContext('photo','facade');if($('closeAnalysis'))$('closeAnalysis').click();invalidate()})});
 railItem($('myImage'),'photo','Minha imagem');one('.rail-primary').insertBefore($('myImage'),ctxButtons.find(b=>b.dataset.context==='water'));
 $('myImage').addEventListener('click',()=>{if($('closeAnalysis'))$('closeAnalysis').click()});
 link('layers','Formas e tamanhos','formas.html');
 const arc=$('archiveTop'),count=$('recordCount');railItem(arc,'folder','Meus desenhos','secondary');if(count)arc.append(count);arc.addEventListener('click',()=>document.body.classList.add('showing-archive'));

 const row=one('.classrow');turma.body.append(row);
 moveHelp($('mission'));moveHelp($('help')?.closest('details'));moveHelp(one('.credits'));moveHelp(one('main>footer'));
 const aside=one('#explorer .grid>aside');const note=document.createElement('details');note.className='minimal-fold';note.innerHTML='<summary>Nome do desenho</summary>';aside.append(note);[...aside.children].filter(n=>!['resultLabel','mainResult','metrics','conversion','saveDrawing','saveStatus','savedCorner'].includes(n.id)&&n!==note).forEach(n=>note.append(n));
 const conversions=fold($('conversion'),'Outras unidades');
 const base=render;render=function(...args){base(...args);sync()};
 function sync(){if($('archive').hidden){const destination=location.pathname+(context==='photo'?(photoView==='custom'?'#minha-imagem':'?lugar=photo&imagem='+photoView):(context==='city'?'':'?lugar='+context));if(location.pathname+location.search+location.hash!==destination)history.replaceState(null,'',destination)}document.body.classList.toggle('showing-archive',!$('archive').hidden);if(conversions)conversions.hidden=$('conversion').hidden;document.querySelectorAll('[data-tool]').forEach(b=>{b.textContent=({distance:'Distância',perimeter:'Perímetro',area:'Área',forms:'Formas'})[b.dataset.tool];b.setAttribute('aria-pressed',String(b.dataset.tool===tool))});const photo=context==='photo',custom=photo&&photoView==='custom';ctxButtons.forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.context===context&&!custom)));$('myImage').setAttribute('aria-pressed',String(custom));$('contextTitle').textContent=custom?'Minha imagem':photo?'Catedral':({city:'Medir no mapa',water:'Rios e baías',land:'Áreas rurais'})[context];if($('savedCorner'))$('savedCorner').hidden=true;document.querySelectorAll('#metrics p').forEach(p=>{p.hidden=tool==='area'&&p.textContent.startsWith('Área:')||tool==='perimeter'&&p.textContent.startsWith('Perímetro:')});}
 $('backExplore').addEventListener('click',()=>{document.body.classList.remove('showing-archive');invalidate()});
 const clear=document.createElement('button');clear.textContent='Nova medida';clear.type='button';clear.onclick=()=>{$('newDrawing').click()};clear.className='compact-new-measure';one('.tools').append(clear);$('newDrawing').textContent='Nova medida';$('undo').textContent='Desfazer';$('fit').textContent='Enquadrar';
 $('earth').textContent='Google Earth';$('chooseImage').textContent='Enviar imagem';
 // Brief controls, existing upload handlers and attribution are kept intact.
 $('photoCredit').classList.add('quiet-credit');
 $('reflection').closest('label').hidden=true;if(one('.reflection'))one('.reflection').hidden=true;turma.el.hidden=true;
 sync();invalidate();
}
})();
