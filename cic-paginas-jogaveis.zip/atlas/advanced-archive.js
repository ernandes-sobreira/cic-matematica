(function(){
 const original=agRender;let savedId=null,savedPoints='';
 const button=document.createElement('button');button.id='agSaveDrawing';button.className='primary';button.textContent='Salvar desenho';
 const status=document.createElement('p');status.className='caption';status.setAttribute('role','status');
 $('agExport').after(button,status);
 function refresh(){const valid=agMode==='draw'&&agPts.length>=3&&!intersects(agPts)&&area(agPts)>0;button.hidden=agMode!=='draw';button.disabled=!valid;status.textContent=agMode!=='draw'?'':savedPoints===JSON.stringify(agPts)?'Desenho salvo em Meus desenhos.':agPts.length?'Desenho não salvo.':'Desenhe e clique em Salvar desenho.'}
 agRender=function(keep){original(keep);if(!agPts.length){savedId=null;savedPoints=''}refresh()};
 button.onclick=()=>{if(button.disabled)return;try{const id=savedId||crypto.randomUUID();GeometryStore.save({id,name:'Área do laboratório avançado',context:'advanced',tool:'area',shape:'contour',points:agPts.map(p=>[...p]),stage:$('level').value,year:$('schoolYear').value,updated:new Date().toISOString(),reflection:'Desenho feito no laboratório de cenários.',source:'Mapa: contorno do aluno'});savedId=id;savedPoints=JSON.stringify(agPts);refresh()}catch(e){status.textContent='Não foi possível salvar o desenho. Tente novamente.'}};
 try{const transfer=JSON.parse(localStorage.getItem('cic-area-for-model')||'null');if(transfer&&Number.isFinite(transfer.area)&&transfer.area>=0){agMode='manual';$('agArea').value=transfer.area;$('agUnit').value='1';agRender();localStorage.removeItem('cic-area-for-model')}}catch(e){}
 refresh();
})();
