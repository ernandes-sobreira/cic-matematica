(function(){
 const E=ShapeEditor,M=ShapeMath,A=AngleMath,svg=document.getElementById('shapeCanvas'),$=id=>document.getElementById(id),fmt=n=>Number(n).toLocaleString('pt-BR',{maximumFractionDigits:1});
 let visible=true,mode=E.getState().angleMeasure?.points?.length?'three':'vertex',selected=0,all=false,notice='',dragPoint=null;
 const bar=document.createElement('section');bar.className='angle-panel';bar.setAttribute('aria-label','Medir e ajustar ângulos');
 bar.innerHTML='<div class="angle-tools"><button id="angleToggle" type="button" aria-pressed="true">Ângulos</button><select id="angleMode" aria-label="Onde medir o ângulo"><option value="vertex">Nos vértices</option><option value="three">Escolher 3 pontos</option></select><label class="check" id="angleAllLabel"><input id="angleAll" type="checkbox">Todos</label><button id="angleReset" type="button" hidden>Novos pontos</button></div><div class="angle-edit"><select id="angleVertex" aria-label="Escolher vértice"></select><label>Ângulo (°)<input id="angleValue" type="number" min="0.1" max="359.9" step="0.1" inputmode="decimal"></label><button id="applyAngle" type="button">Aplicar ângulo</button></div><p id="angleStatus" role="status"></p>';
 svg.before(bar);
 function curved(){const s=E.getState();return s.free||M.defs.find(d=>d.id===s.preset)?.curve}
 function picks(){const s=E.getState(),m=s.angleMeasure;return m&&Array.isArray(m.points)?m.points.slice(0,3).filter(p=>Array.isArray(p)&&p.length===2&&p.every(Number.isFinite)).map(p=>[s.origin[0]+p[0]*s.width,s.origin[1]+p[1]*s.height]):[]}
 function norm(p){const s=E.getState();return[(p[0]-s.origin[0])/s.width,(p[1]-s.origin[1])/s.height]}
 function vertexInfo(index){const ps=E.getPoints(),s=E.getState(),n=ps.length;if(n<3||!s.closed&&(index===0||index===n-1))return null;const a=ps[(index+n-1)%n],b=ps[index],c=ps[(index+1)%n],simple=M.analyze(ps,s.closed),interior=s.closed&&simple.angles.length===n&&!curved();let value=interior?simple.angles[index]:A.angle(a,b,c);if(value===null)return null;const signed=ps.reduce((v,p,i)=>v+p[0]*ps[(i+1)%n][1]-ps[(i+1)%n][0]*p[1],0),cross=(a[0]-b[0])*(c[1]-b[1])-(a[1]-b[1])*(c[0]-b[0]);return {a,b,c,value,interior,side:interior?(signed>0?-1:1):(cross<0?-1:1)}}
 function measurement(){if(mode==='vertex')return vertexInfo(selected);const p=picks();if(p.length!==3)return null;const reflex=!!E.getState().angleMeasure?.reflex,value=A.angle(...p,reflex);if(value===null)return null;const cross=(p[0][0]-p[1][0])*(p[2][1]-p[1][1])-(p[0][1]-p[1][1])*(p[2][0]-p[1][0]);return {a:p[0],b:p[1],c:p[2],value,side:(cross<0?-1:1)*(reflex?-1:1),interior:false}}
 function arc(info,px,highlight=false){
  const {a,b,c,value,side}=info,start=Math.atan2(a[1]-b[1],a[0]-b[0]),delta=side*value*Math.PI/180,r=Math.min(27*px,Math.hypot(a[0]-b[0],a[1]-b[1])*.3,Math.hypot(c[0]-b[0],c[1]-b[1])*.3);if(r<2*px)return '';
  const p=[b[0]+r*Math.cos(start),b[1]+r*Math.sin(start)],q=[b[0]+r*Math.cos(start+delta),b[1]+r*Math.sin(start+delta)],t=start+delta/2,lr=r+13*px,color=highlight?'#b85a0d':'#1765e5';
  return '<path d="M '+p.join(' ')+' A '+r+' '+r+' 0 '+(value>180?1:0)+' '+(delta>0?1:0)+' '+q.join(' ')+'" fill="none" stroke="'+color+'" stroke-width="'+(highlight?2.5:1.5)*px+'"/><text x="'+(b[0]+lr*Math.cos(t))+'" y="'+(b[1]+lr*Math.sin(t))+'" text-anchor="middle" dominant-baseline="middle" font-family="system-ui" font-size="'+(highlight?14:12)*px+'" fill="'+color+'" stroke="white" stroke-width="'+3*px+'" paint-order="stroke">'+fmt(value)+'°</text>';
 }
 function render(){
  svg.querySelector('#angleOverlay')?.remove();$('angleToggle').setAttribute('aria-pressed',String(visible));$('angleMode').hidden=!visible;$('angleAllLabel').hidden=!visible||mode!=='vertex';$('angleReset').hidden=!visible||mode!=='three';bar.querySelector('.angle-edit').hidden=!visible;$('angleStatus').hidden=!visible;
  if(!visible)return;
  const ps=E.getPoints(),s=E.getState(),isCurve=curved();
  if(isCurve&&mode==='vertex'){mode='three';notice='Escolha A, o vértice B e depois C sobre a figura ou em qualquer posição.'}
  $('angleMode').value=mode;$('angleAllLabel').hidden=mode!=='vertex';$('angleReset').hidden=mode!=='three';$('angleVertex').hidden=mode!=='vertex';
  const selection=$('angleVertex');if(mode==='vertex'){if(selected>=ps.length)selected=0;const values=[...selection.options].map(o=>o.value);if(values.length!==ps.length){selection.replaceChildren();ps.forEach((p,i)=>{const o=document.createElement('option');o.value=String(i);o.textContent='Vértice '+(i+1);selection.append(o)})}selection.value=String(selected)}
  const info=measurement();$('applyAngle').disabled=!info;$('angleValue').disabled=!info;if(document.activeElement!==$('angleValue'))$('angleValue').value=info?Number(info.value.toFixed(1)):'';
  $('angleStatus').textContent=notice||(mode==='three'?(picks().length<3?'Marque A, depois o vértice B e por último C.':'Ângulo ABC: '+fmt(info?.value||0)+'°. Aplicar muda o raio BC; a figura continua igual.'):(info?'Vértice '+(selected+1)+': '+fmt(info.value)+'°. Aplicar move o vértice seguinte, mantendo os outros pontos.':'Escolha um vértice com dois lados, ou use 3 pontos.'));
  if(E.getMode()==='draw')return;
  const px=1/Math.abs(svg.getScreenCTM()?.a||1);let content='';
  if(mode==='vertex'){
   for(let i=0;i<ps.length;i++)if(all||i===selected){const a=vertexInfo(i);if(a)content+=arc(a,px,i===selected)}
   if(ps[selected])content+='<circle cx="'+ps[selected][0]+'" cy="'+ps[selected][1]+'" r="'+7*px+'" fill="#fff7dd" stroke="#b85a0d" stroke-width="'+2*px+'"/>';
  }else{const p=picks();if(p.length>1)content+='<polyline points="'+p.map(p=>p.join(',')).join(' ')+'" fill="none" stroke="#b85a0d" stroke-width="'+2*px+'" stroke-dasharray="'+5*px+' '+4*px+'"/>';if(info)content+=arc(info,px,true);p.forEach((q,i)=>{content+='<circle data-angle-point="'+i+'" cx="'+q[0]+'" cy="'+q[1]+'" r="'+18*px+'" fill="transparent" pointer-events="all"/><circle cx="'+q[0]+'" cy="'+q[1]+'" r="'+5*px+'" fill="white" stroke="#b85a0d" stroke-width="'+2*px+'"/><text x="'+(q[0]+11*px)+'" y="'+(q[1]-11*px)+'" fill="#9b4b0a" font-family="system-ui" font-size="'+13*px+'">'+['A','B','C'][i]+'</text>'})}
  const layer=document.createElementNS('http://www.w3.org/2000/svg','g');layer.id='angleOverlay';layer.setAttribute('pointer-events','none');layer.innerHTML=content;svg.append(layer);
 }
 $('angleToggle').onclick=()=>{visible=!visible;E.render()};
 $('angleMode').onchange=()=>{mode=$('angleMode').value;notice='';E.render()};
 $('angleAll').onchange=()=>{all=$('angleAll').checked;notice='';E.render()};
 $('angleVertex').onchange=()=>{selected=+$('angleVertex').value;notice='';E.render()};
 $('angleReset').onclick=()=>{notice='';E.setMeasure(null)};
 function pointerDown(e,p){
  if(!visible||E.getMode()==='draw')return false;
  if(mode==='vertex'){if(e.target.dataset.point!==undefined){selected=+e.target.dataset.point;notice='';render()}return false}
  e.preventDefault();const marker=e.target.dataset.anglePoint;
  if(marker!==undefined){dragPoint=+marker;E.beginChange();svg.setPointerCapture(e.pointerId);return true}
  const old=picks(),ps=E.getPoints(),scale=Math.abs(svg.getScreenCTM()?.a||1),nearest=ps.map(q=>({q,d:Math.hypot(q[0]-p[0],q[1]-p[1])})).sort((a,b)=>a.d-b.d)[0];if(nearest&&nearest.d*scale<18)p=nearest.q;
  const chosen=old.length===3?[]:old;if(chosen.some(q=>Math.hypot(q[0]-p[0],q[1]-p[1])<1e-9)){notice='Escolha posições diferentes para A, B e C.';render();return true}chosen.push(p);notice='';E.setMeasure({points:chosen.map(norm),reflex:false});return true;
 }
 svg.addEventListener('pointermove',e=>{if(dragPoint===null)return;e.preventDefault();const p=svg.createSVGPoint();p.x=e.clientX;p.y=e.clientY;const q=p.matrixTransform(svg.getScreenCTM().inverse()),chosen=picks();chosen[dragPoint]=[q.x,q.y];notice='';E.setMeasure({points:chosen.map(norm),reflex:!!E.getState().angleMeasure?.reflex},false)});
 function end(e){if(dragPoint===null)return;dragPoint=null;if(svg.hasPointerCapture(e.pointerId))svg.releasePointerCapture(e.pointerId)}svg.addEventListener('pointerup',end);svg.addEventListener('pointercancel',end);
 $('applyAngle').onclick=()=>{
  const value=+$('angleValue').value,info=measurement();if(!info||!Number.isFinite(value)||value<=0||value>=360){notice='Informe um ângulo maior que 0° e menor que 360°.';render();return}
  if(mode==='three'){const p=picks(),minor=A.angle(...p),cross=(p[0][0]-p[1][0])*(p[2][1]-p[1][1])-(p[0][1]-p[1][1])*(p[2][0]-p[1][0]),side=cross<0?-1:1;p[2]=A.turn(...p,value,side);notice='Ângulo de '+fmt(value)+'° aplicado aos raios AB e BC. A figura continua igual.';E.setMeasure({points:p.map(norm),reflex:value>180});return}
  if(!info.interior&&value>180){notice='Neste traçado cruzado, use até 180° entre os lados. Para outro ângulo, escolha 3 pontos.';render();return}
  const ps=E.getPoints(),next=(selected+1)%ps.length;ps[next]=A.turn(info.a,info.b,info.c,value,info.side);
  if(info.interior){const candidate=M.analyze(ps,E.getState().closed);if(candidate.angles.length!==ps.length||Math.abs(candidate.angles[selected]-value)>1e-5){notice='Esse valor não mantém um polígono simples nesta posição. Experimente outro valor ou escolha 3 pontos.';render();return}}
  notice='Ângulo de '+fmt(value)+'° aplicado. O vértice seguinte foi movido.';E.changePoints(ps);E.setView();E.render();
 };
 window.ShapeAngles={render,pointerDown,reset(){mode='vertex';selected=0;notice=''}};E.render();
})();
