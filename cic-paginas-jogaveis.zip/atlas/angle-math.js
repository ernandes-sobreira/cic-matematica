(function(root){
 const sub=(a,b)=>[a[0]-b[0],a[1]-b[1]],len=v=>Math.hypot(...v),cross=(a,b)=>a[0]*b[1]-a[1]*b[0];
 function angle(a,b,c,reflex=false){const u=sub(a,b),v=sub(c,b);if(len(u)<1e-10||len(v)<1e-10)return null;const value=Math.atan2(Math.abs(cross(u,v)),u[0]*v[0]+u[1]*v[1])*180/Math.PI;return reflex?360-value:value}
 function turn(a,b,c,degrees,side){const u=sub(a,b),v=sub(c,b),r=len(v);if(len(u)<1e-10||r<1e-10)return null;const sign=side|| (cross(u,v)<0?-1:1),t=Math.atan2(u[1],u[0])+sign*degrees*Math.PI/180;return[b[0]+r*Math.cos(t),b[1]+r*Math.sin(t)]}
 root.AngleMath={angle,turn};
})(typeof window==='undefined'?globalThis:window);
