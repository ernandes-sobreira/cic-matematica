/* Recorte didático para a aula: não é delimitação de lote ou da praça. */
if(location.hash==='#aula-area'){
const grade=new URLSearchParams(location.search).get('turma'),classMap={'5':['iniciais','5'],'7':['finais','7'],'2m':['medio','2']};hideArchive();context='city';tool='area';shape='contour';points=[];activeId=null;$('shape').value=shape;$('drawingName').value='';$('reflection').value='';if(classMap[grade]){const cl=classMap[grade];$('stage').value=cl[0];setYears();if([...$('year').options].some(o=>o.value===cl[1]))$('year').value=cl[1]}render();if(map){map.invalidateSize();map.setView([-16.0655,-57.6875],16)}$('saveStatus').textContent='Marque os cantos da área que deseja medir. Os retângulos da folha são exercícios, sem localização no mapa.';
}

if(location.hash==='#aula-catedral'){const grade=new URLSearchParams(location.search).get('turma'),classMap={'5':['iniciais','5'],'7':['finais','7'],'2m':['medio','2']};hideArchive();context='photo';photoView='facade';tool='distance';shape='triangle';if(classMap[grade]){$('stage').value=classMap[grade][0];setYears();$('year').value=classMap[grade][1]}points=[];activeId=null;render();$('saveStatus').textContent='Estudo de simetria na imagem; perspectiva não equivale a levantamento do edifício.';}

if(location.hash==='#minha-imagem')$('myImage').click();

{const preset=new URLSearchParams(location.search).get('lugar');if(['city','water','land'].includes(preset)){hideArchive();loadContext(preset);}else if(preset==='photo'){const view=new URLSearchParams(location.search).get('imagem');hideArchive();loadContext('photo',['facade','aerial','inside','custom'].includes(view)?view:'facade');}}
