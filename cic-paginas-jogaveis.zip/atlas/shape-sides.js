(function(){
 const E=ShapeEditor,svg=document.getElementById('shapeCanvas'),fmt=n=>Number(n).toLocaleString('pt-BR',{maximumFractionDigits:2}),label=document.createElement('label');label.className='check';
 label.innerHTML='<input id="shapeShowSides" type="checkbox" checked>Medidas dos lados';document.querySelector('.shape-bottom').append(label);
 const list=document.createElement('section');list.className='shape-side-list';document.getElementById('shapeAngles').append(list);
 function draw(){
  svg.querySelector('#shapeSideOverlay')?.remove();list.replaceChildren();const s=E.getState(),ps=E.getPoints(),curve=ShapeMath.defs.find(d=>d.id===s.preset)?.curve;
  label.hidden=!!curve||ps.length<2;
  if(ps.length<2||curve)return;
  const heading=document.createElement('p');heading.textContent=s.free?'Trechos aproximados do traçado':'Comprimento de cada lado';list.append(heading);const ol=document.createElement('ol');list.append(ol);
  const count=s.closed?ps.length:ps.length-1,scale=Math.abs(svg.getScreenCTM()?.a||1);let content='';
  for(let i=0;i<count;i++){const j=(i+1)%ps.length,a=ps[i],b=ps[j],dx=b[0]-a[0],dy=b[1]-a[1],len=Math.hypot(dx,dy);if(len<1e-9)continue;const name=(i+1)+'–'+(j+1),text=name+': '+fmt(len)+' '+s.unit,li=document.createElement('li');li.textContent=text;ol.append(li);
   if(!document.getElementById('shapeShowSides').checked||E.getMode()==='draw'||s.free&&count>20)continue;
   const p=[(a[0]+b[0])/2-dy/len*15/scale,(a[1]+b[1])/2+dx/len*15/scale];
   content+='<text x="'+p[0]+'" y="'+p[1]+'" text-anchor="middle" dominant-baseline="middle" font-family="system-ui" font-size="'+12/scale+'" font-weight="500" fill="#164e80" stroke="white" stroke-width="'+4/scale+'" paint-order="stroke">'+text+'</text>';
  }
  if(content){const g=document.createElementNS('http://www.w3.org/2000/svg','g');g.id='shapeSideOverlay';g.setAttribute('pointer-events','none');g.innerHTML=content;svg.append(g)}
 }
 document.getElementById('shapeShowSides').onchange=draw;window.ShapeSides={draw};E.render();
})();
