window.BiologyPhotos={
  "abobreiro-tree": {
    "file": "bio-images/abobreiro-tree.jpg",
    "author": "Alejandro  Bayer Tamayo from Armenia, Colombia",
    "license": "CC BY-SA 2.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/2.0",
    "date": "2015-02-27",
    "source": "https://commons.wikimedia.org/wiki/File:B%C3%BAcaro_-_P%C3%ADsamo_(Erythrina_fusca)_-_Flickr_-_Alejandro_Bayer.jpg",
    "title": "File:Búcaro - Písamo (Erythrina fusca) - Flickr - Alejandro Bayer.jpg"
  },
  "abobreiro-flower": {
    "file": "bio-images/abobreiro-flower.jpg",
    "author": "Alejandro  Bayer Tamayo from Armenia, Colombia",
    "license": "CC BY-SA 2.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/2.0",
    "date": "2015-02-27",
    "source": "https://commons.wikimedia.org/wiki/File:B%C3%BAcaro_-_P%C3%ADsamo_(Erythrina_fusca)_-_Flickr_-_Alejandro_Bayer_(2).jpg",
    "title": "File:Búcaro - Písamo (Erythrina fusca) - Flickr - Alejandro Bayer (2).jpg"
  },
  "abobreiro-trunk": {
    "file": "bio-images/abobreiro-trunk.jpg",
    "author": "Alejandro  Bayer Tamayo from Armenia, Colombia",
    "license": "CC BY-SA 2.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/2.0",
    "date": "2014-06-11",
    "source": "https://commons.wikimedia.org/wiki/File:B%C3%BAcaro_(Erythrina_fusca)_(14222085630).jpg",
    "title": "File:Búcaro (Erythrina fusca) (14222085630).jpg"
  },
  "jenipapo-tree": {
    "file": "bio-images/jenipapo-tree.jpg",
    "author": "Alex Popovkin, Bahia, Brazil from Brazil",
    "license": "CC BY 2.0",
    "licenseUrl": "https://creativecommons.org/licenses/by/2.0",
    "date": "2008-04-10",
    "source": "https://commons.wikimedia.org/wiki/File:Genipa_americana_L._-_Flickr_-_Alex_Popovkin,_Bahia,_Brazil.jpg",
    "title": "File:Genipa americana L. - Flickr - Alex Popovkin, Bahia, Brazil.jpg"
  },
  "jenipapo-fruit": {
    "file": "bio-images/jenipapo-fruit.jpg",
    "author": "CostaPPPR",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "date": "2017-05-20",
    "source": "https://commons.wikimedia.org/wiki/File:JenipapoDSC9363.jpg",
    "title": "File:JenipapoDSC9363.jpg"
  },
  "jenipapo-seeds": {
    "file": "bio-images/jenipapo-seeds.jpg",
    "author": "Cody H.",
    "license": "CC BY 2.0",
    "licenseUrl": "https://creativecommons.org/licenses/by/2.0",
    "date": "2004-02-26",
    "source": "https://commons.wikimedia.org/wiki/File:Genipa_americana_L._fruits_(codiferous).jpg",
    "title": "File:Genipa americana L. fruits (codiferous).jpg"
  },
  "manduvi-tree": {
    "file": "bio-images/manduvi-tree.jpg",
    "author": "Christian Pirkl",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "date": "2010-01-31",
    "source": "https://commons.wikimedia.org/wiki/File:Sterculia_apetala_001_Anacag%C3%BCita.jpg",
    "title": "File:Sterculia apetala 001 Anacagüita.jpg"
  },
  "manduvi-flower": {
    "file": "bio-images/manduvi-flower.jpg",
    "author": "Dr. Ariel Rodríguez-Vargas",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "date": "2016-01-08",
    "source": "https://commons.wikimedia.org/wiki/File:Panama_Tree_(Sterculia_apetala)_flower.JPG",
    "title": "File:Panama Tree (Sterculia apetala) flower.JPG"
  },
  "manduvi-fruit": {
    "file": "bio-images/manduvi-fruit.jpg",
    "author": "Dr. Ariel Rodríguez-Vargas",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "date": "2016-01-08",
    "source": "https://commons.wikimedia.org/wiki/File:Arbol_Panama_con_flores_y_frutos._Sterculia_apetala_fruit_and_leaves.JPG",
    "title": "File:Arbol Panama con flores y frutos. Sterculia apetala fruit and leaves.JPG"
  },
  "manduvi-seeds": {
    "file": "bio-images/manduvi-seeds.jpg",
    "author": "Carlos A. Padrón P.",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "date": "2023-03-01",
    "source": "https://commons.wikimedia.org/wiki/File:Chinches_adultos_y_ninfas_del_g%C3%A9nero_Dysdercus_01-03-2023.jpg",
    "title": "File:Chinches adultos y ninfas del género Dysdercus 01-03-2023.jpg"
  },
  "tuiuiu": {
    "file": "bio-images/tuiuiu.jpg",
    "author": "Williamcarvalhojk",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "date": "2022-05-10",
    "source": "https://commons.wikimedia.org/wiki/File:Esta%C3%A7%C3%A3oEcologicadeTaiam%C3%A3_WilliamCarvalhojk_(02).jpg",
    "title": "File:EstaçãoEcologicadeTaiamã WilliamCarvalhojk (02).jpg"
  },
  "ariranha": {
    "file": "bio-images/ariranha.jpg",
    "author": "Túllio F",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "date": "2024-08-25",
    "source": "https://commons.wikimedia.org/wiki/File:Excurs%C3%A3o_pelo_Rio_Paraguai_em_C%C3%A1ceres_(Mato_Grosso)_108.jpg",
    "title": "File:Excursão pelo Rio Paraguai em Cáceres (Mato Grosso) 108.jpg"
  },
  "onca": {
    "file": "bio-images/onca.jpg",
    "author": "Queucer",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "date": "2021-10-13",
    "source": "https://commons.wikimedia.org/wiki/File:On%C3%A7a-pintada_na_Esta%C3%A7%C3%A3o_Ecol%C3%B3gica_de_Taiam%C3%A3_por_Queucer_(01).jpg",
    "title": "File:Onça-pintada na Estação Ecológica de Taiamã por Queucer (01).jpg"
  },
  "capivara": {
    "file": "bio-images/capivara.jpg",
    "author": "Giles Laurent",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "date": "2024-08-08",
    "source": "https://commons.wikimedia.org/wiki/File:046_Capybara_by_the_river_in_Encontro_das_%C3%81guas_State_Park_Photo_by_Giles_Laurent.jpg",
    "title": "File:046 Capybara by the river in Encontro das Águas State Park Photo by Giles Laurent.jpg"
  },
  "jacare": {
    "file": "bio-images/jacare.jpg",
    "author": "Giles Laurent",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "date": "2024-08-11",
    "source": "https://commons.wikimedia.org/wiki/File:038_Yacare_caiman_in_Encontro_das_%C3%81guas_State_Park_Photo_by_Giles_Laurent.jpg",
    "title": "File:038 Yacare caiman in Encontro das Águas State Park Photo by Giles Laurent.jpg"
  }
};