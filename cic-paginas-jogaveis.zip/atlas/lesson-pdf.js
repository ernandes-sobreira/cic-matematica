/* PDF textual, sem serviço externo; o HTML com imagens continua disponível. */
(function(){
 function latin(s){return s.normalize('NFC').replace(/[“”]/g,'"').replace(/[‘’]/g,"'").replace(/[–—]/g,'-').replace(/…/g,'...').replace(/→/g,':').replace(/[^\x20-\xFF\n]/g,' ')}
 function pdfText(root){
  const lines=[];
  function walk(n){if(n.nodeType===3){return n.textContent}if(n.nodeType!==1||['SCRIPT','STYLE','BUTTON','IMG','SVG'].includes(n.tagName))return '';const block=/^(H[1-6]|P|DIV|SECTION|LI|TR|SUMMARY|FIGCAPTION|BR)$/.test(n.tagName);return(block?'\n':'')+[...n.childNodes].map(walk).join(n.tagName==='TR'?' | ':'')+(block?'\n':'')}
  for(const paragraph of latin(walk(root)).split(/\n+/)){const words=paragraph.trim().split(/\s+/);let line='';if(!words[0])continue;for(const word of words){if((line+' '+word).length>91){lines.push(line);line=word}else line+=(line?' ':'')+word}if(line)lines.push(line);lines.push('')}
  const pages=[];for(let i=0;i<lines.length;i+=49)pages.push(lines.slice(i,i+49));if(!pages.length)pages.push(['CIC']);
  const objects=[null,'<< /Type /Catalog /Pages 2 0 R >>','', '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>'];
  const refs=[];
  pages.forEach((ls,i)=>{const id=objects.length,content=id+1;refs.push(id+' 0 R');objects.push('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R >> >> /Contents '+content+' 0 R >>');let stream='BT /F1 11 Tf 45 795 Td 15 TL\n';const escape=s=>s.replace(/([\\()])/g,'\\$1');ls.forEach((l,j)=>{if(j)stream+='T*\n';stream+='('+escape(l)+') Tj\n'});stream+='ET\nBT /F1 9 Tf 45 25 Td (CIC - '+(i+1)+' / '+pages.length+') Tj ET';objects.push('<< /Length '+stream.length+' >>\nstream\n'+stream+'\nendstream')});
  objects[2]='<< /Type /Pages /Kids ['+refs.join(' ')+'] /Count '+pages.length+' >>';let out='%PDF-1.4\n',offsets=[0];for(let i=1;i<objects.length;i++){offsets.push(out.length);out+=i+' 0 obj\n'+objects[i]+'\nendobj\n'}const xref=out.length;out+='xref\n0 '+objects.length+'\n0000000000 65535 f \n';for(const o of offsets.slice(1))out+=String(o).padStart(10,'0')+' 00000 n \n';out+='trailer\n<< /Size '+objects.length+' /Root 1 0 R >>\nstartxref\n'+xref+'\n%%EOF';return new Uint8Array([...out].map(c=>c.charCodeAt(0)));
 }
 window.CicLessonPDF=function(root,filename){const blob=new Blob([pdfText(root)],{type:'application/pdf'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=filename+'.pdf';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000)};
})();
