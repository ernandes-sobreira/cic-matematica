(function(root){
 const eps=1e-9, cross=(a,b)=>a[0]*b[1]-a[1]*b[0],sub=(a,b)=>[a[0]-b[0],a[1]-b[1]],length=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1]);
 function bounds(ps){return {minX:Math.min(...ps.map(p=>p[0])),minY:Math.min(...ps.map(p=>p[1])),maxX:Math.max(...ps.map(p=>p[0])),maxY:Math.max(...ps.map(p=>p[1]))}}
 function normalize(ps){const b=bounds(ps),w=b.maxX-b.minX||1,h=b.maxY-b.minY||1;return ps.map(p=>[(p[0]-b.minX)/w,(p[1]-b.minY)/h])}
 function regular(n,step=1){const p=Array.from({length:n},(_,i)=>[Math.cos(-Math.PI/2+2*Math.PI*i/n),Math.sin(-Math.PI/2+2*Math.PI*i/n)]);return Array.from({length:n},(_,i)=>p[i*step%n])}
 function star(n){return Array.from({length:n*2},(_,i)=>{const r=i%2?.43:1,t=-Math.PI/2+Math.PI*i/n;return [r*Math.cos(t),r*Math.sin(t)]})}
 const defs=[
 ['square','Quadrado',[[0,0],[1,0],[1,1],[0,1]]],
 ['rectangle','Retângulo',[[0,0],[1.6,0],[1.6,1],[0,1]]],
 ['triangle','Triângulo equilátero',[[0,Math.sqrt(3)/2],[1,Math.sqrt(3)/2],[.5,0]]],
 ['right','Triângulo retângulo',[[0,0],[0,1],[1.4,1]]],
 ['isosceles','Triângulo isósceles',[[0,1.4],[1,1.4],[.5,0]]],
 ['scalene','Triângulo escaleno',[[0,1],[1.4,1],[.35,0]]],
 ['diamond','Losango',[[.5,0],[1,.7],[.5,1.4],[0,.7]]],
 ['parallelogram','Paralelogramo',[[.4,0],[1.8,0],[1.4,1],[0,1]]],
 ['trapezoid','Trapézio isósceles',[[.4,0],[1.2,0],[1.6,1],[0,1]]],
 ['right-trapezoid','Trapézio retângulo',[[0,0],[1,0],[1.6,1],[0,1]]],
 ['kite','Deltoide (pipa)',[[.5,0],[1,.5],[.5,1.5],[0,.5]]],
 ...Array.from({length:9},(_,i)=>[String(i+5),['Pentágono','Hexágono','Heptágono','Octógono','Eneágono','Decágono','Undecágono','Dodecágono','Tridecágono'][i]+' regular',regular(i+5)]),
 ['star4','Estrela de 4 pontas',star(4)],['star5','Estrela de 5 pontas',star(5)],['star6','Estrela de 6 pontas',star(6)],['star8','Estrela de 8 pontas',star(8)],
 ['pentagram','Pentagrama (linhas cruzadas)',regular(5,2)],
 ['cross','Cruz',[[.35,0],[.65,0],[.65,.35],[1,.35],[1,.65],[.65,.65],[.65,1],[.35,1],[.35,.65],[0,.65],[0,.35],[.35,.35]]],
 ['L','Forma em L',[[0,0],[.35,0],[.35,.65],[1,.65],[1,1],[0,1]]],
 ['T','Forma em T',[[0,0],[1,0],[1,.3],[.65,.3],[.65,1],[.35,1],[.35,.3],[0,.3]]],
 ['arrow','Seta',[[0,.3],[.6,.3],[.6,0],[1,.5],[.6,1],[.6,.7],[0,.7]]],
 ['chevron','Chevron',[[0,0],[.4,0],[1,.5],[.4,1],[0,1],[.6,.5]]],
 ['circle','Círculo',regular(128),true],['ellipse','Elipse',regular(128).map(p=>[p[0]*1.6,p[1]]),true],
 ['semicircle','Semicírculo',Array.from({length:65},(_,i)=>[Math.cos(Math.PI*i/64),-Math.sin(Math.PI*i/64)]),true],
 ['quarter','Quarto de círculo',[[0,0],...Array.from({length:65},(_,i)=>[Math.cos(Math.PI*i/128),Math.sin(Math.PI*i/128)])],true]
 ].map(([id,name,raw,curve])=>{const b=bounds(raw);return {id,name,points:normalize(raw),ratio:(b.maxY-b.minY)/(b.maxX-b.minX),curve:!!curve}});
 function analyze(ps,closed=true){
  if(ps.length<2)return {valid:false,area:0,perimeter:0,intersections:0,angles:[],vertices:ps.length,sides:0};
  const b=bounds(ps),scale=Math.max(1,b.maxX-b.minX,b.maxY-b.minY),tol=eps*scale*scale;
  const n=ps.length,count=closed?n:n-1,edges=Array.from({length:count},(_,i)=>[ps[i],ps[(i+1)%n]]),hits=[],ys=ps.map(p=>p[1]);let overlaps=false;
  for(let i=0;i<count;i++)for(let j=i+1;j<count;j++){if(j===i+1||closed&&i===0&&j===count-1)continue;const [a,b]=edges[i],[c,d]=edges[j],r=sub(b,a),s=sub(d,c),den=cross(r,s),ca=sub(c,a);if(Math.abs(den)<tol){if(Math.abs(cross(ca,r))<tol&&length(a,b)>eps){const t1=(ca[0]*r[0]+ca[1]*r[1])/(r[0]**2+r[1]**2),t2=((d[0]-a[0])*r[0]+(d[1]-a[1])*r[1])/(r[0]**2+r[1]**2);if(Math.min(1,Math.max(t1,t2))-Math.max(0,Math.min(t1,t2))>eps)overlaps=true}continue}const t=cross(ca,s)/den,u=cross(ca,r)/den;if(t>eps&&t<1-eps&&u>eps&&u<1-eps){const q=[a[0]+t*r[0],a[1]+t*r[1]];ys.push(q[1]);if(!hits.some(p=>length(p,q)<scale*1e-7))hits.push(q)}}
  let area=0;
  if(closed&&!overlaps){const cuts=[...new Set(ys)].sort((a,b)=>a-b);for(let i=0;i<cuts.length-1;i++){const low=cuts[i],high=cuts[i+1];if(high-low<eps)continue;const y=(low+high)/2,xs=[];for(const [a,b] of edges){if(y>Math.min(a[1],b[1])&&y<Math.max(a[1],b[1]))xs.push(a[0]+(y-a[1])*(b[0]-a[0])/(b[1]-a[1]))}xs.sort((a,b)=>a-b);for(let j=0;j+1<xs.length;j+=2)area+=(xs[j+1]-xs[j])*(high-low)}}
  const signed=ps.reduce((s,p,i)=>s+cross(p,ps[(i+1)%n]),0),angles=[];
  if(closed&&!hits.length&&!overlaps&&Math.abs(signed)>tol)for(let i=0;i<n;i++){const v=sub(ps[i],ps[(i+n-1)%n]),w=sub(ps[(i+1)%n],ps[i]);if(Math.hypot(...v)>eps&&Math.hypot(...w)>eps)angles.push(180-Math.sign(signed)*Math.atan2(cross(v,w),v[0]*w[0]+v[1]*w[1])*180/Math.PI)}
  return {valid:edges.some(e=>length(...e)>eps),area:closed&&!overlaps?area:null,perimeter:edges.reduce((s,e)=>s+length(...e),0),intersections:hits.length,hits,overlaps,angles,vertices:n,sides:edges.filter(e=>length(...e)>eps).length,width:b.maxX-b.minX,height:b.maxY-b.minY};
 }
 root.ShapeMath={defs,analyze,normalize,bounds};
})(typeof window==='undefined'?globalThis:window);
