function addLandscapeLayers(map,street){
const satellite=L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',{maxNativeZoom:17,maxZoom:19,attribution:'Imagery © Esri, Maxar, Earthstar Geographics, GIS User Community'});
const relief=L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Shaded_Relief/MapServer/tile/{z}/{y}/{x}',{maxNativeZoom:13,maxZoom:19,attribution:'Relevo © Esri, USGS, NOAA'});
const labels=L.tileLayer('https://services.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}',{maxNativeZoom:16,maxZoom:19,attribution:'Referências © Esri',pane:'overlayPane'});
L.control.layers({'Mapa de ruas':street,'Satélite e paisagem':satellite,'Relevo sombreado':relief},{'Nomes dos lugares':labels},{collapsed:!!document.body.dataset.mathPage,position:'topright'}).addTo(map);
[satellite,relief].forEach(layer=>layer.on('tileerror',()=>{if(map.hasLayer(layer)){map.removeLayer(layer);street.addTo(map);const el=document.getElementById(map.getContainer().id==='waterMap'?'waterStatus':'mapstatus');if(el)el.textContent='Esta imagem não carregou. Voltamos ao mapa de ruas. Você também pode explorar no Google Earth.'}}));
}
