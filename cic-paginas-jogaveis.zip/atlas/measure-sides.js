(function(){
 const svg=$('drawing'),bar=document.querySelector('.measure-angle-controls'),label=document.createElement('label');
 label.innerHTML='<input id="mapShowSides" type="checkbox" checked>Medidas dos lados';bar.append(label);let layer=map&&L.layerGroup().addTo(map);
 function draw(){
  if(layer)layer.clearLayers();svg.querySelector('#measureSideOverlay')?.remove();
  const st=stats(),path=st.path||[],photo=context==='photo',valid=!st.circle&&path.length>=2&&(!photo?!!map:true);label.hidden=!valid;if(valid)bar.hidden=false;
  if(!valid||!$('mapShowSides').checked)return;
  const closed=tool!=='distance'&&path.length>=3,count=closed?path.length:path.length-1,scale=photo?Math.abs(svg.getScreenCTM()?.a||1):1;
  let markup='';
  for(let i=0;i<count;i++){
   const j=(i+1)%path.length,value=dist(path[i],path[j],photo);if(value<1e-9)continue;
   let a,b;if(photo){a=path[i].map(v=>v*scale);b=path[j].map(v=>v*scale)}else{const z=map.getZoom(),center=map.project(map.getCenter(),z),size=map.getSize();const toScreen=p=>{const q=map.project(p,z);return[q.x-center.x+size.x/2,q.y-center.y+size.y/2]};a=toScreen(path[i]);b=toScreen(path[j])}
   const dx=b[0]-a[0],dy=b[1]-a[1],len=Math.hypot(dx,dy);if(len<1e-9)continue;
   const p=[(a[0]+b[0])/2-dy/len*15,(a[1]+b[1])/2+dx/len*15],name=tool==='forms'&&shape==='rect'?'Lado '+(i+1):String.fromCharCode(65+i%26)+String.fromCharCode(65+j%26),text=name+': '+fmt(value,1)+' '+(photo?'u':'m');
   if(photo)markup+='<text x="'+p[0]/scale+'" y="'+p[1]/scale+'" text-anchor="middle" dominant-baseline="middle" font-family="system-ui" font-weight="600" font-size="'+12/scale+'" fill="#164e80" stroke="white" stroke-width="'+4/scale+'" paint-order="stroke">'+text+'</text>';
   else L.marker(map.containerPointToLatLng(p),{interactive:false,keyboard:false,zIndexOffset:700,icon:L.divIcon({className:'map-side-label',html:'<span>'+text+'</span>',iconSize:[130,24],iconAnchor:[65,12]})}).addTo(layer);
  }
  if(photo&&markup){const g=document.createElementNS('http://www.w3.org/2000/svg','g');g.id='measureSideOverlay';g.setAttribute('pointer-events','none');g.innerHTML=markup;svg.append(g)}
 }
 $('mapShowSides').onchange=draw;const original=render;render=function(...args){original(...args);draw()};if(map)map.on('zoomend moveend resize',draw);window.MeasureSides={draw};draw();
})();
