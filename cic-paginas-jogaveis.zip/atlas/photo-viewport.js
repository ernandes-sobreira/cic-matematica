(function(){
 const stage=$('photoStage'),svg=$('drawing'),image=$('photo');
 const layer=document.createElement('div');layer.className='photo-layer';stage.append(layer);layer.append(image,svg);
 const controls=document.createElement('div');controls.className='photo-controls';controls.setAttribute('aria-label','Visualização da imagem');
 controls.innerHTML='<button type="button" aria-label="Afastar imagem">−</button><output>100%</output><button type="button" aria-label="Aproximar imagem">+</button><button type="button" aria-pressed="false">Mover foto</button>';
 stage.before(controls);
 const [minus,plus,move]=controls.querySelectorAll('button'),output=controls.querySelector('output');
 let z=1,x=0,y=0,moving=false,key='',gesture=null,blocked=false;
 const touches=new Map();
 function sizeHandles(){const scale=svg.getScreenCTM()?.a;if(!scale)return;svg.querySelectorAll('.vertex-dot').forEach(n=>n.setAttribute('r',6/Math.abs(scale)));svg.querySelectorAll('.vertex-hit').forEach(n=>n.setAttribute('r',18/Math.abs(scale)));svg.querySelectorAll('[stroke]:not(.vertex-hit)').forEach(n=>{n.setAttribute('vector-effect','none');n.setAttribute('stroke-width',(n.classList.contains('vertex-dot')?2:2.5)/Math.abs(scale))})}
 function apply(){layer.style.transform='translate('+x+'px,'+y+'px) scale('+z+')';output.textContent=Math.round(z*100)+'%';stage.classList.toggle('moving-photo',moving);move.setAttribute('aria-pressed',String(moving));minus.disabled=z<=1;plus.disabled=z>=12;sizeHandles();window.MeasureAngles?.draw();window.MeasureSides?.draw()}
 function zoom(next,cx=stage.clientWidth/2,cy=stage.clientHeight/2){next=Math.max(1,Math.min(12,next));x=cx-(cx-x)*next/z;y=cy-(cy-y)*next/z;z=next;if(z===1)x=y=0;apply()}
 function reset(){z=1;x=y=0;apply()}
 minus.onclick=()=>zoom(z/1.5);plus.onclick=()=>zoom(z*1.5);move.onclick=()=>{moving=!moving;apply()};
 const oldFit=$('fit').onclick;$('fit').onclick=()=>context==='photo'?reset():oldFit();
 stage.addEventListener('wheel',e=>{e.preventDefault();const r=stage.getBoundingClientRect();zoom(z*Math.exp(-e.deltaY*.002),e.clientX-r.left,e.clientY-r.top)},{passive:false});
 stage.addEventListener('pointerdown',e=>{
  touches.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(touches.size===2){gesture=null;dragging=null;blocked=true}
  if(moving||touches.size>1){e.stopImmediatePropagation();e.preventDefault();stage.setPointerCapture(e.pointerId);blocked=true;gesture={x:e.clientX,y:e.clientY}}
 },true);
 stage.addEventListener('pointermove',e=>{
  if(!touches.has(e.pointerId))return;
  const prev=touches.get(e.pointerId),others=[...touches.entries()].filter(([id])=>id!==e.pointerId);
  if(others.length){e.stopImmediatePropagation();e.preventDefault();const other=others[0][1];const before=Math.hypot(prev.x-other.x,prev.y-other.y),after=Math.hypot(e.clientX-other.x,e.clientY-other.y),r=stage.getBoundingClientRect();if(before>0)zoom(z*after/before,(e.clientX+other.x)/2-r.left,(e.clientY+other.y)/2-r.top)}
  else if(moving&&gesture){e.stopImmediatePropagation();x+=e.clientX-prev.x;y+=e.clientY-prev.y;apply()}
  touches.set(e.pointerId,{x:e.clientX,y:e.clientY});
 },true);
 function end(e){touches.delete(e.pointerId);if(blocked){e.stopImmediatePropagation();if(stage.hasPointerCapture(e.pointerId))stage.releasePointerCapture(e.pointerId);if(!touches.size){gesture=null;setTimeout(()=>blocked=false,100)}}}
 stage.addEventListener('pointerup',end,true);stage.addEventListener('pointercancel',end,true);
 stage.addEventListener('click',e=>{if(moving||blocked){e.preventDefault();e.stopImmediatePropagation()}},true);
 const original=render;render=function(keep){original(keep);controls.hidden=context!=='photo'||stage.hidden;const next=photoView+image.getAttribute('src');if(next!==key){key=next;moving=false;reset()}stage.style.height=Math.round(stage.clientWidth*(photos[photoView]?.h||600)/1000)+'px';sizeHandles()};
 new ResizeObserver(()=>{stage.style.height=Math.round(stage.clientWidth*(photos[photoView]?.h||600)/1000)+'px';sizeHandles()}).observe(stage);
 const style=document.createElement('style');style.textContent='.math-minimal #photoStage{position:relative;touch-action:none;overflow:hidden;min-height:180px}.photo-layer{position:relative;width:100%;transform-origin:0 0}.math-minimal #photoStage #photo{display:block;width:100%;height:auto}.math-minimal #photoStage #drawing{position:absolute;inset:0;width:100%;height:100%}.photo-controls{display:flex;align-items:center;gap:7px;margin:10px 0}.photo-controls output{font:14px system-ui;min-width:48px;text-align:center}.photo-controls button{min-width:42px;min-height:42px}.moving-photo,.moving-photo #drawing{cursor:grab!important}.math-minimal #uploadImageButton{position:relative;display:inline-flex;align-items:center;min-height:44px;font:600 14px system-ui;padding:11px 14px;border:1px solid #d9e2ed;border-radius:9px;overflow:hidden;cursor:pointer}.math-minimal #uploadImageButton input[type=file]{position:absolute;inset:0;display:block!important;opacity:.01;width:100%;height:100%;margin:0;padding:0;cursor:pointer;font-size:16px}.math-minimal #uploadImageButton:focus-within{outline:3px solid #f0b132}.math-minimal #saveDrawing{grid-column:1/-1;background:#1765e5;color:white}.math-minimal button:disabled{opacity:.5}';document.head.append(style);render();
})();
